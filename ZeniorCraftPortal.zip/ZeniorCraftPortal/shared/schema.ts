import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const serverStats = pgTable("server_stats", {
  id: serial("id").primaryKey(),
  isOnline: boolean("is_online").notNull().default(false),
  playerCount: integer("player_count").notNull().default(0),
  maxPlayers: integer("max_players").notNull().default(100),
  uptime: text("uptime").notNull().default("0%"),
  totalPlayers: integer("total_players").notNull().default(0),
  blocksPlaced: integer("blocks_placed").notNull().default(0),
  serverAge: integer("server_age").notNull().default(0),
  totalPlaytime: integer("total_playtime").notNull().default(0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const onlinePlayers = pgTable("online_players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  avatarColor: text("avatar_color").notNull(),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertServerStatsSchema = createInsertSchema(serverStats).omit({
  id: true,
  updatedAt: true,
});

export const insertOnlinePlayerSchema = createInsertSchema(onlinePlayers).omit({
  id: true,
  joinedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type ServerStats = typeof serverStats.$inferSelect;
export type InsertServerStats = z.infer<typeof insertServerStatsSchema>;

export type OnlinePlayer = typeof onlinePlayers.$inferSelect;
export type InsertOnlinePlayer = z.infer<typeof insertOnlinePlayerSchema>;
