import { Hammer, Coins, Shield, Home, Trophy, Headphones } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Hammer,
    title: "Survival",
    description: "Klasik survival deneyimi ile hayatta kalma mücadelesi ver!"
  },
  {
    icon: Coins,
    title: "Ekonomi",
    description: "Gelişmiş ekonomi sistemi ile ticaret yap ve zengin ol!"
  },
  {
    icon: Shield,
    title: "Anti-Grief",
    description: "Yapıların güvende! Gelişmiş koruma sistemleri."
  },
  {
    icon: Home,
    title: "Klanlar",
    description: "Arkadaşlarınla klan kur ve birlikte büyü!"
  },
  {
    icon: Trophy,
    title: "Etkinlikler",
    description: "Düzenli etkinlikler ve turnuvalar!"
  },
  {
    icon: Headphones,
    title: "7/24 Destek",
    description: "Her zaman yardıma hazır aktif yönetim ekibi!"
  }
];

export default function FeaturesSection() {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="font-pixel text-3xl md:text-4xl text-center text-mc-gold mb-12">
          Sunucu Özellikleri
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card 
                key={index}
                className="bg-gray-900 border-4 border-mc-green hover:border-mc-gold transition-colors duration-300 block-shadow group"
              >
                <CardContent className="p-6">
                  <div className="text-4xl text-mc-orange mb-4 group-hover:scale-110 transition-transform duration-300">
                    <IconComponent className="h-10 w-10" />
                  </div>
                  <h3 className="font-pixel text-lg text-mc-gold mb-3">{feature.title}</h3>
                  <p className="text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
