import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface ServerStats {
  isOnline: boolean;
  playerCount: number;
  dataSource?: string;
}

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  const { data: stats } = useQuery<ServerStats>({
    queryKey: ["/api/server/stats"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const NavigationLinks = ({ mobile = false }) => (
    <div className={`${mobile ? "flex flex-col space-y-4" : "hidden md:flex items-center space-x-6"}`}>
      <button 
        onClick={() => scrollToSection("home")} 
        className="hover:text-mc-gold transition-colors duration-200"
      >
        Ana Sayfa
      </button>
      <button 
        onClick={() => scrollToSection("stats")} 
        className="hover:text-mc-gold transition-colors duration-200"
      >
        İstatistikler
      </button>
      <button 
        onClick={() => scrollToSection("rules")} 
        className="hover:text-mc-gold transition-colors duration-200"
      >
        Kurallar
      </button>
      <button 
        onClick={() => scrollToSection("contact")} 
        className="hover:text-mc-gold transition-colors duration-200"
      >
        İletişim
      </button>
    </div>
  );

  return (
    <header className={`bg-mc-dark-green border-b-4 border-mc-green sticky top-0 z-50 transition-all duration-300 ${isScrolled ? "shadow-lg" : ""}`}>
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-pixel text-mc-gold">ZeniorCraft</div>
            <div className="hidden md:flex items-center space-x-2">
              <div 
                className={`server-status-indicator ${stats?.isOnline ? "bg-online" : "bg-offline"}`}
              />
              <div className="flex flex-col">
                <span className={`text-sm ${stats?.isOnline ? "text-green-400" : "text-red-400"}`}>
                  {stats?.isOnline ? "Çevrimiçi" : "Çevrimdışı"}
                </span>
                {stats?.dataSource && (
                  <span className={`text-xs ${stats.dataSource === 'live' ? 'text-green-300' : 'text-red-300'}`}>
                    {stats.dataSource === 'live' ? 'Canlı Veri' : 'Sunucu Erişilemez'}
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <NavigationLinks />
          
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-white">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-gray-800 border-mc-green">
              <div className="flex flex-col space-y-8 mt-8">
                <div className="flex items-center space-x-2">
                  <div 
                    className={`server-status-indicator ${stats?.isOnline ? "bg-online" : "bg-offline"}`}
                  />
                  <div className="flex flex-col">
                    <span className={`text-sm ${stats?.isOnline ? "text-green-400" : "text-red-400"}`}>
                      {stats?.isOnline ? "Çevrimiçi" : "Çevrimdışı"}
                    </span>
                    {stats?.dataSource && (
                      <span className={`text-xs ${stats.dataSource === 'live' ? 'text-green-300' : 'text-red-300'}`}>
                        {stats.dataSource === 'live' ? 'Canlı Veri' : 'Sunucu Erişilemez'}
                      </span>
                    )}
                  </div>
                </div>
                <NavigationLinks mobile />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
