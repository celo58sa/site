import { AlertTriangle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

const rules = [
  {
    title: "Saygı Gösterin",
    description: "Diğer oyunculara karşı saygılı olun. Küfür, hakaret ve spam yasaktır."
  },
  {
    title: "Grief Yasak",
    description: "Başkalarının yapılarını tahrip etmek, çalmak kesinlikle yasaktır."
  },
  {
    title: "Hile Yapmayın",
    description: "X-ray, fly hack gibi hileler kullanmak kalıcı ban sebebidir."
  },
  {
    title: "Doğal Yapıları Koruyun",
    description: "Spawn yakınındaki doğal alanları ve ortak yapıları koruyun."
  },
  {
    title: "Yöneticilere Uyun",
    description: "Yönetici ve moderatör kararlarına saygı gösterin."
  }
];

export default function RulesSection() {
  return (
    <section id="rules" className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <h2 className="font-pixel text-3xl md:text-4xl text-center text-mc-gold mb-12">
          Sunucu Kuralları
        </h2>
        
        <div className="max-w-4xl mx-auto">
          <Card className="bg-gray-900 border-4 border-mc-green block-shadow">
            <CardContent className="p-8">
              <div className="space-y-6">
                {rules.map((rule, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="bg-mc-green text-white rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-semibold text-mc-gold mb-2">{rule.title}</h3>
                      <p className="text-gray-300">{rule.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <Alert className="mt-8 bg-mc-dark-green border-2 border-mc-green">
                <AlertTriangle className="h-4 w-4 text-mc-tan" />
                <AlertDescription className="text-mc-tan">
                  Bu kurallara uymayan oyuncular uyarı, kick veya ban cezası alabilir.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
