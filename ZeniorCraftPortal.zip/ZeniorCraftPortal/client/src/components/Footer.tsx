export default function Footer() {
  const socialLinks = [
    { icon: "fab fa-discord", href: "#", color: "hover:text-indigo-400" },
    { icon: "fab fa-instagram", href: "#", color: "hover:text-pink-400" },
    { icon: "fab fa-youtube", href: "#", color: "hover:text-red-500" },
    { icon: "fas fa-envelope", href: "#", color: "hover:text-mc-orange" },
  ];

  return (
    <footer className="bg-mc-dark-green border-t-4 border-mc-green py-12">
      <div className="container mx-auto px-4">
        <div className="text-center">
          <div className="font-pixel text-2xl text-mc-gold mb-4">ZeniorCraft</div>
          <p className="text-mc-tan mb-4">En iyi Minecraft sunucu deneyimi</p>
          
          <div className="flex justify-center space-x-6 mb-6">
            {socialLinks.map((link, index) => (
              <a 
                key={index}
                href={link.href} 
                className={`text-mc-tan ${link.color} transition-colors duration-200`}
              >
                <i className={`${link.icon} text-2xl`} />
              </a>
            ))}
          </div>
          
          <div className="border-t border-mc-brown pt-6">
            <p className="text-gray-400 text-sm">
              © 2024 ZeniorCraft. Tüm hakları saklıdır. | Minecraft Mojang Studios'un markasıdır.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
