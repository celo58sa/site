import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Copy, Server, Users, Globe, Clock, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface ServerStats {
  isOnline: boolean;
  playerCount: number;
  maxPlayers: number;
  uptime: string;
  dataSource?: string;
  lastChecked?: string;
}

export default function HeroSection() {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const { data: stats, isLoading } = useQuery<ServerStats>({
    queryKey: ["/api/server/stats"],
    refetchInterval: 30000,
  });

  const copyServerIP = async () => {
    const serverIP = "oyna.zeniorcraft.xyz";
    try {
      await navigator.clipboard.writeText(serverIP);
      setCopied(true);
      toast({
        title: "Başarılı!",
        description: "Sunucu IP'si panoya kopyalandı!",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Hata",
        description: "IP kopyalanırken bir hata oluştu.",
        variant: "destructive",
      });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div 
          className="w-full h-full bg-gradient-to-br from-mc-green via-mc-brown to-mc-dark-green"
          style={{
            backgroundImage: `
              repeating-linear-gradient(
                45deg,
                transparent,
                transparent 35px,
                rgba(139, 69, 19, 0.1) 35px,
                rgba(139, 69, 19, 0.1) 70px
              )
            `
          }}
        />
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="font-pixel text-4xl md:text-6xl text-mc-gold mb-6 animate-pulse">
          ZeniorCraft
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
          En iyi Minecraft deneyimi için bize katıl!<br />
          Arkadaşlarınla birlikte eğlenceli anlar yaşa.
        </p>
        
        {/* Server Connection Card */}
        <Card className="bg-gray-800 border-4 border-mc-green mb-8 max-w-md mx-auto block-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-center mb-4">
              <Server className="text-mc-gold text-2xl mr-3 h-8 w-8" />
              <h3 className="font-pixel text-lg text-mc-gold">Sunucu IP</h3>
            </div>
            <div className="font-mono text-xl text-white bg-gray-900 px-4 py-2 rounded border-2 border-gray-600 mb-4">
              oyna.zeniorcraft.xyz
            </div>
            <Button 
              onClick={copyServerIP}
              className="w-full bg-mc-green hover:bg-mc-dark-green text-white font-bold py-3 px-6 block-shadow"
              disabled={copied}
            >
              {copied ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Kopyalandı!
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  IP'yi Kopyala
                </>
              )}
            </Button>
          </CardContent>
        </Card>
        
        {/* Live Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gray-800 border-4 border-mc-brown block-shadow">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-mc-orange mx-auto mb-2" />
              <div className="text-3xl font-bold text-mc-gold">
                {isLoading ? "..." : stats?.playerCount || 0}
              </div>
              <div className="text-sm text-gray-400">Aktif Oyuncu</div>
              {stats?.dataSource && (
                <div className={`text-xs mt-1 ${stats.dataSource === 'live' ? 'text-green-400' : 'text-red-400'}`}>
                  {stats.dataSource === 'live' ? '● Canlı' : '● Sunucu Çevrimdışı'}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-4 border-mc-brown block-shadow">
            <CardContent className="p-6 text-center">
              <Globe className="h-8 w-8 text-mc-orange mx-auto mb-2" />
              <div className="text-3xl font-bold text-mc-gold">
                {isLoading ? "..." : stats?.maxPlayers || 100}
              </div>
              <div className="text-sm text-gray-400">Maksimum Oyuncu</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-4 border-mc-brown block-shadow">
            <CardContent className="p-6 text-center">
              <Clock className="h-8 w-8 text-mc-orange mx-auto mb-2" />
              <div className="text-3xl font-bold text-mc-gold">
                {isLoading ? "..." : stats?.uptime || "99.8%"}
              </div>
              <div className="text-sm text-gray-400">Çalışma Süresi</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
