import { useState } from "react";
import { Mail, Send } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const contactMethods = [
    {
      icon: "fab fa-discord",
      name: "Discord",
      value: "discord.gg/zeniorcraft",
      color: "text-indigo-400"
    },
    {
      icon: "fas fa-envelope",
      name: "E-posta",
      value: "info@zeniorcraft.xyz",
      color: "text-mc-orange"
    },
    {
      icon: "fab fa-instagram",
      name: "Instagram",
      value: "@zeniorcraft",
      color: "text-pink-400"
    },
    {
      icon: "fab fa-youtube",
      name: "YouTube",
      value: "ZeniorCraft Official",
      color: "text-red-500"
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Hata",
        description: "Lütfen tüm alanları doldurun.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Başarılı!",
        description: "Mesajınız başarıyla gönderildi! En kısa sürede size dönüş yapacağız.",
      });
      
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      toast({
        title: "Hata",
        description: "Mesaj gönderilirken bir hata oluştu.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="font-pixel text-3xl md:text-4xl text-center text-mc-gold mb-12">
          İletişim
        </h2>
        
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="bg-gray-800 border-4 border-mc-green block-shadow">
            <CardContent className="p-8">
              <h3 className="font-pixel text-xl text-mc-gold mb-6">Bize Ulaşın</h3>
              
              <div className="space-y-4">
                {contactMethods.map((method, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <i className={`${method.icon} text-2xl ${method.color}`} />
                    <div>
                      <div className="font-semibold text-white">{method.name}</div>
                      <div className="text-gray-400">{method.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-4 border-mc-green block-shadow">
            <CardContent className="p-8">
              <h3 className="font-pixel text-xl text-mc-gold mb-6">Mesaj Gönder</h3>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-gray-300">İsim</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="bg-gray-900 border-2 border-gray-600 focus:border-mc-gold"
                    placeholder="Adınız"
                    disabled={isSubmitting}
                  />
                </div>
                
                <div>
                  <Label htmlFor="email" className="text-gray-300">E-posta</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="bg-gray-900 border-2 border-gray-600 focus:border-mc-gold"
                    placeholder="email@example.com"
                    disabled={isSubmitting}
                  />
                </div>
                
                <div>
                  <Label htmlFor="message" className="text-gray-300">Mesaj</Label>
                  <Textarea
                    id="message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => handleInputChange("message", e.target.value)}
                    className="bg-gray-900 border-2 border-gray-600 focus:border-mc-gold resize-none"
                    placeholder="Mesajınız..."
                    disabled={isSubmitting}
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-mc-green hover:bg-mc-dark-green text-white font-bold py-3 px-6 block-shadow"
                  disabled={isSubmitting}
                >
                  <Send className="mr-2 h-4 w-4" />
                  {isSubmitting ? "Gönderiliyor..." : "Mesaj Gönder"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
