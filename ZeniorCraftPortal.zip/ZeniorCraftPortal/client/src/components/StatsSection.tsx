import { useQuery } from "@tanstack/react-query";
import { Users, Box, Calendar, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface ServerStats {
  totalPlayers: number;
  blocksPlaced: number;
  serverAge: number;
  totalPlaytime: number;
}

interface OnlinePlayer {
  id: number;
  username: string;
  avatarColor: string;
}

export default function StatsSection() {
  const { data: stats, isLoading: statsLoading } = useQuery<ServerStats>({
    queryKey: ["/api/server/stats"],
    refetchInterval: 60000,
  });

  const { data: onlinePlayers, isLoading: playersLoading } = useQuery<OnlinePlayer[]>({
    queryKey: ["/api/server/players"],
    refetchInterval: 30000,
  });

  return (
    <section id="stats" className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="font-pixel text-3xl md:text-4xl text-center text-mc-gold mb-12">
          Sunucu İstatistikleri
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-mc-green to-mc-dark-green block-shadow">
            <CardContent className="p-6 text-center">
              <Users className="h-10 w-10 text-mc-gold mx-auto mb-4" />
              {statsLoading ? (
                <Skeleton className="h-8 w-16 mx-auto mb-2" />
              ) : (
                <div className="text-3xl font-bold text-white mb-2">
                  {stats?.totalPlayers?.toLocaleString() || "0"}
                </div>
              )}
              <div className="text-mc-tan">Toplam Oyuncu</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-mc-brown to-amber-800 block-shadow">
            <CardContent className="p-6 text-center">
              <Box className="h-10 w-10 text-mc-gold mx-auto mb-4" />
              {statsLoading ? (
                <Skeleton className="h-8 w-20 mx-auto mb-2" />
              ) : (
                <div className="text-3xl font-bold text-white mb-2">
                  {stats?.blocksPlaced?.toLocaleString() || "0"}
                </div>
              )}
              <div className="text-mc-tan">Yerleştirilen Blok</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-purple-600 to-purple-800 block-shadow">
            <CardContent className="p-6 text-center">
              <Calendar className="h-10 w-10 text-mc-gold mx-auto mb-4" />
              {statsLoading ? (
                <Skeleton className="h-8 w-12 mx-auto mb-2" />
              ) : (
                <div className="text-3xl font-bold text-white mb-2">
                  {stats?.serverAge || "0"}
                </div>
              )}
              <div className="text-mc-tan">Gün Aktif</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-red-600 to-red-800 block-shadow">
            <CardContent className="p-6 text-center">
              <Heart className="h-10 w-10 text-mc-gold mx-auto mb-4" />
              {statsLoading ? (
                <Skeleton className="h-8 w-16 mx-auto mb-2" />
              ) : (
                <div className="text-3xl font-bold text-white mb-2">
                  {stats?.totalPlaytime?.toLocaleString() || "0"}
                </div>
              )}
              <div className="text-mc-tan">Saat Oynanma</div>
            </CardContent>
          </Card>
        </div>
        
        {/* Live Player List */}
        <Card className="bg-gray-800 border-4 border-mc-green block-shadow">
          <CardContent className="p-6">
            <h3 className="font-pixel text-xl text-mc-gold mb-6 text-center">Çevrimiçi Oyuncular</h3>
            
            {playersLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="bg-gray-900 rounded-lg p-3 flex items-center space-x-3">
                    <Skeleton className="w-8 h-8 rounded" />
                    <Skeleton className="h-4 flex-1" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {onlinePlayers?.map((player) => (
                  <div 
                    key={player.id}
                    className="bg-gray-900 rounded-lg p-3 flex items-center space-x-3 border-2 border-gray-700 hover:border-mc-gold transition-colors"
                  >
                    <div 
                      className="w-8 h-8 rounded pixelated"
                      style={{ backgroundColor: player.avatarColor }}
                    />
                    <span className="text-sm text-white truncate">{player.username}</span>
                  </div>
                ))}
                {(!onlinePlayers || onlinePlayers.length === 0) && (
                  <div className="col-span-full text-center text-gray-400 py-8">
                    Şu anda çevrimiçi oyuncu bulunmuyor.
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
