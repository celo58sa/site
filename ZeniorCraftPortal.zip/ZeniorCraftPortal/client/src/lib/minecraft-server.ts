// Utility functions for Minecraft server operations

export interface ServerPingResult {
  online: boolean;
  latency: number;
  timestamp: string;
}

export interface MinecraftServerInfo {
  ip: string;
  port: number;
  name: string;
}

export const ZENIORCRAFT_SERVER: MinecraftServerInfo = {
  ip: "oyna.zeniorcraft.xyz",
  port: 25565,
  name: "ZeniorCraft"
};

export async function pingMinecraftServer(): Promise<ServerPingResult> {
  try {
    const response = await fetch("/api/server/ping");
    if (!response.ok) {
      throw new Error("Failed to ping server");
    }
    return await response.json();
  } catch (error) {
    return {
      online: false,
      latency: 0,
      timestamp: new Date().toISOString(),
    };
  }
}

export function formatPlayerCount(current: number, max: number): string {
  return `${current}/${max}`;
}

export function formatUptime(uptimePercent: string): string {
  return uptimePercent;
}

export function getServerStatusColor(isOnline: boolean): string {
  return isOnline ? "text-green-400" : "text-red-400";
}

export function getServerStatusText(isOnline: boolean): string {
  return isOnline ? "Çevrimiçi" : "Çevrimdışı";
}

// Minecraft player avatar colors (simulated)
export const AVATAR_COLORS = [
  "#8B4513", // Brown
  "#2563eb", // Blue
  "#16a34a", // Green
  "#7c3aed", // Purple
  "#dc2626", // Red
  "#ca8a04", // Yellow/Gold
  "#ea580c", // Orange
  "#0891b2", // Cyan
  "#be123c", // Rose
  "#7c2d12", // Dark Brown
];

export function getRandomAvatarColor(): string {
  return AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
}
