import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertServerStatsSchema, insertOnlinePlayerSchema } from "@shared/schema";
import { status } from "minecraft-server-util";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get server stats
  app.get("/api/server/stats", async (req, res) => {
    try {
      // Try to get real server status
      let realStats = null;
      let serverReachable = false;
      
      try {
        console.log("Attempting to connect to oyna.zeniorcraft.xyz:25565...");
        const serverStatus = await status("oyna.zeniorcraft.xyz", 25565, { timeout: 5000 });
        console.log("Server status received:", serverStatus);
        
        realStats = {
          isOnline: true,
          playerCount: serverStatus.players.online || 0,
          maxPlayers: serverStatus.players.max || 100,
          uptime: "99.8%",
        };
        serverReachable = true;
        console.log("Real server data:", realStats);
      } catch (error) {
        console.log("Server connection failed:", error instanceof Error ? error.message : String(error));
        // Server is offline or unreachable - show this clearly
        realStats = {
          isOnline: false,
          playerCount: 0,
          maxPlayers: 100,
          uptime: "0%",
        };
      }

      // Update storage with real data
      const currentStats = await storage.getServerStats();
      const updatedStats = await storage.updateServerStats({
        ...realStats,
        totalPlayers: currentStats?.totalPlayers || 2847,
        blocksPlaced: currentStats?.blocksPlaced || 1234567,
        serverAge: currentStats?.serverAge || 342,
        totalPlaytime: currentStats?.totalPlaytime || 15678,
      });

      // Add metadata about data source
      const response = {
        ...updatedStats,
        dataSource: serverReachable ? "live" : "offline",
        lastChecked: new Date().toISOString()
      };

      res.json(response);
    } catch (error) {
      console.error("Error fetching server stats:", error);
      res.status(500).json({ message: "Failed to fetch server stats" });
    }
  });

  // Update server stats
  app.post("/api/server/stats", async (req, res) => {
    try {
      const validatedData = insertServerStatsSchema.parse(req.body);
      const stats = await storage.updateServerStats(validatedData);
      res.json(stats);
    } catch (error) {
      res.status(400).json({ message: "Invalid server stats data" });
    }
  });

  // Get online players
  app.get("/api/server/players", async (req, res) => {
    try {
      const players = await storage.getOnlinePlayers();
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch online players" });
    }
  });

  // Add online player
  app.post("/api/server/players", async (req, res) => {
    try {
      const validatedData = insertOnlinePlayerSchema.parse(req.body);
      const player = await storage.addOnlinePlayer(validatedData);
      res.json(player);
    } catch (error) {
      res.status(400).json({ message: "Invalid player data" });
    }
  });

  // Remove online player
  app.delete("/api/server/players/:username", async (req, res) => {
    try {
      await storage.removeOnlinePlayer(req.params.username);
      res.json({ message: "Player removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove player" });
    }
  });

  // Server ping endpoint to check if server is online
  app.get("/api/server/ping", async (req, res) => {
    try {
      const startTime = Date.now();
      let pingResult;
      
      try {
        await status("oyna.zeniorcraft.xyz", 25565, { timeout: 5000 });
        const latency = Date.now() - startTime;
        pingResult = {
          online: true,
          latency: latency,
          timestamp: new Date().toISOString(),
        };
      } catch (error) {
        pingResult = {
          online: false,
          latency: 0,
          timestamp: new Date().toISOString(),
        };
      }
      
      res.json(pingResult);
    } catch (error) {
      console.error("Error pinging server:", error);
      res.status(500).json({ message: "Failed to ping server" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
