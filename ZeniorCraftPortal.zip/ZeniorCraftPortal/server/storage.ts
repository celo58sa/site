import { users, serverStats, onlinePlayers, type User, type InsertUser, type ServerStats, type InsertServerStats, type OnlinePlayer, type InsertOnlinePlayer } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getServerStats(): Promise<ServerStats | undefined>;
  updateServerStats(stats: InsertServerStats): Promise<ServerStats>;
  
  getOnlinePlayers(): Promise<OnlinePlayer[]>;
  addOnlinePlayer(player: InsertOnlinePlayer): Promise<OnlinePlayer>;
  removeOnlinePlayer(username: string): Promise<void>;
  clearOnlinePlayers(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private serverStatsData: ServerStats | null;
  private onlinePlayersData: Map<number, OnlinePlayer>;
  private userIdCounter: number;
  private playerIdCounter: number;

  constructor() {
    this.users = new Map();
    this.onlinePlayersData = new Map();
    this.userIdCounter = 1;
    this.playerIdCounter = 1;
    
    // Initialize with default server stats
    this.serverStatsData = {
      id: 1,
      isOnline: true,
      playerCount: 47,
      maxPlayers: 100,
      uptime: "99.8%",
      totalPlayers: 2847,
      blocksPlaced: 1234567,
      serverAge: 342,
      totalPlaytime: 15678,
      updatedAt: new Date(),
    };

    // Initialize with some online players
    const mockPlayers = [
      { username: "Steve47", avatarColor: "#8B4513" },
      { username: "AlexCraft", avatarColor: "#2563eb" },
      { username: "Creeper99", avatarColor: "#16a34a" },
      { username: "EnderMan", avatarColor: "#7c3aed" },
      { username: "DiamondHunter", avatarColor: "#dc2626" },
      { username: "GoldMiner", avatarColor: "#ca8a04" },
    ];

    mockPlayers.forEach(player => {
      const onlinePlayer: OnlinePlayer = {
        id: this.playerIdCounter++,
        username: player.username,
        avatarColor: player.avatarColor,
        joinedAt: new Date(),
      };
      this.onlinePlayersData.set(onlinePlayer.id, onlinePlayer);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getServerStats(): Promise<ServerStats | undefined> {
    if (this.serverStatsData) {
      // Update player count based on online players
      this.serverStatsData.playerCount = this.onlinePlayersData.size;
      this.serverStatsData.updatedAt = new Date();
    }
    return this.serverStatsData || undefined;
  }

  async updateServerStats(stats: InsertServerStats): Promise<ServerStats> {
    if (this.serverStatsData) {
      this.serverStatsData = {
        ...this.serverStatsData,
        ...stats,
        updatedAt: new Date(),
      };
    } else {
      this.serverStatsData = {
        id: 1,
        isOnline: false,
        playerCount: 0,
        maxPlayers: 100,
        uptime: "0%",
        totalPlayers: 0,
        blocksPlaced: 0,
        serverAge: 0,
        totalPlaytime: 0,
        ...stats,
        updatedAt: new Date(),
      };
    }
    return this.serverStatsData;
  }

  async getOnlinePlayers(): Promise<OnlinePlayer[]> {
    return Array.from(this.onlinePlayersData.values());
  }

  async addOnlinePlayer(player: InsertOnlinePlayer): Promise<OnlinePlayer> {
    const id = this.playerIdCounter++;
    const onlinePlayer: OnlinePlayer = {
      ...player,
      id,
      joinedAt: new Date(),
    };
    this.onlinePlayersData.set(id, onlinePlayer);
    return onlinePlayer;
  }

  async removeOnlinePlayer(username: string): Promise<void> {
    for (const [id, player] of [...this.onlinePlayersData.entries()]) {
      if (player.username === username) {
        this.onlinePlayersData.delete(id);
        break;
      }
    }
  }

  async clearOnlinePlayers(): Promise<void> {
    this.onlinePlayersData.clear();
  }
}

export const storage = new MemStorage();
